package com.example.getbetterhappit

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
