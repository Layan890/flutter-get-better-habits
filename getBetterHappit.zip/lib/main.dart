import 'package:flutter/material.dart';

void main() {
  runApp(runner());
}

class runner extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        appBar: AppBar(
          title: Text('B E T T R H A P P I T S',
              style: TextStyle(color: Colors.white)),
          backgroundColor: Colors.pink,
        ),
        body: Container(
          color: Color(0xffe196af),
          child: Center(
            child: Column(
              children: [
                Text('Select the activity today'),
                SizedBox(height: 16.0),
                ElevatedButton(
                  onPressed: null,
                  child: Text('Go for a walk'),
                ),
                SizedBox(height: 8.0),
                TextButton(
                  onPressed: null,
                  child: Text('Drink water'),
                ),
                SizedBox(height: 8.0),
                OutlinedButton(
                  onPressed: null,
                  child: Text('Read a Book'),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
